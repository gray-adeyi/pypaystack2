__title__ = "pypaystack2"
__version__ = "1.0.3"
__author__ = ["Gbenga Adeyi"]
__license__ = "MIT"
__copyright__ = "Copyright 2022."
