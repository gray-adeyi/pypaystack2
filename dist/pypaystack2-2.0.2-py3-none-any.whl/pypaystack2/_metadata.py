__title__ = "pypaystack2"
__version__ = "2.0.2"
__author__ = ["Gbenga Adeyi <adeyigbenga005@gmail.com>"]
__license__ = "MIT"
__copyright__ = "Copyright 2023."
